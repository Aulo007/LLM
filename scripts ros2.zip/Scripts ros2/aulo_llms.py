"""
aulo_llm - Biblioteca para integração com Groq e ElevenLabs
Funções específicas para LLM, transcrição e TTS
Autor: Aulo

Dependências:
    pip install groq elevenlabs python-dotenv
"""

import os
import re
from groq import Groq
from elevenlabs.client import ElevenLabs
from elevenlabs import save
from dotenv import load_dotenv


class AuloLLM:
    """Classe para gerenciar interações com Groq e ElevenLabs."""

    def __init__(
        self, groq_api_key=None, elevenlabs_api_key=None, default_voice_id=None
    ):
        """
        Inicializa os clientes de API.

        Args:
            groq_api_key: Chave API da Groq (opcional, usa variável de ambiente)
            elevenlabs_api_key: Chave API da ElevenLabs (opcional)
            default_voice_id: ID da voz padrão para ElevenLabs (opcional)
        """

        # CARREGANDO AS VARIÁVEIS DE AMBIENTE AQUI NO INÍCIO DO CONSTRUTOR
        load_dotenv()

        # Cliente Groq
        self.groq_api_key = groq_api_key or os.getenv("GROQ_API_KEY")
        if self.groq_api_key:
            self.groq_client = Groq(api_key=self.groq_api_key)
        else:
            self.groq_client = None
            print("⚠️ API Key da Groq não encontrada. Defina GROQ_API_KEY no .env")

        # Cliente ElevenLabs
        self.elevenlabs_api_key = elevenlabs_api_key or os.getenv("ELEVENLABS_API_KEY")
        if self.elevenlabs_api_key:
            self.elevenlabs_client = ElevenLabs(api_key=self.elevenlabs_api_key)
        else:
            self.elevenlabs_client = None
            print(
                "⚠️ API Key da ElevenLabs não encontrada. Defina ELEVENLABS_API_KEY no .env"
            )

        # Voz padrão
        self.default_voice_id = default_voice_id or os.getenv("ELEVENLABS_VOICE_ID")

    def transcribe_audio(
        self, audio_file_path, model_name="whisper-large-v3", language="pt"
    ):
        """
        Transcreve áudio usando Whisper via Groq.

        Args:
            audio_file_path: Caminho para o arquivo de áudio
            model_name: Modelo Whisper (padrão: whisper-large-v3)
            language: Código do idioma (padrão: pt)

        Returns:
            str: Texto transcrito ou None em caso de erro
        """
        if not self.groq_client:
            print("❌ Cliente Groq não inicializado")
            return None

        if not os.path.exists(audio_file_path):
            print(f"❌ Arquivo não encontrado: {audio_file_path}")
            return None

        try:
            print(f"🤖 Transcrevendo áudio com Whisper ({model_name})...")
            with open(audio_file_path, "rb") as audio_file:
                transcription = self.groq_client.audio.transcriptions.create(
                    file=audio_file,
                    model=model_name,
                    language=language,
                    response_format="json",
                )
            print("✅ Transcrição concluída")
            return transcription.text
        except Exception as e:
            print(f"❌ Erro na transcrição: {e}")
            return None

    def query_llm(
        self,
        content,
        model_name="llama-3.3-70b-versatile",
        system_prompt=None,
        temperature=0.7,
        max_tokens=512,
    ):
        """
        Consulta um modelo LLM via Groq.

        Args:
            content: Mensagem do usuário
            model_name: Modelo LLM (padrão: llama-3.3-70b-versatile)
            system_prompt: Prompt do sistema (opcional)
            temperature: Criatividade da resposta (0.0-2.0, padrão: 0.7)
            max_tokens: Limite de tokens na resposta (padrão: 512)

        Returns:
            str: Resposta do modelo
        """
        if not self.groq_client:
            return "❌ Cliente Groq não inicializado"

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": content})

        try:
            chat_completion = self.groq_client.chat.completions.create(
                messages=messages,
                model=model_name,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            response_text = chat_completion.choices[0].message.content

            # Remove tags <think> se presentes (alguns modelos usam isso)
            cleaned_response = re.sub(
                r"<think>.*?</think>", "", response_text, flags=re.DOTALL
            )

            return cleaned_response.strip()
        except Exception as e:
            return f"❌ Erro ao consultar LLM: {e}"

    def generate_speech(
        self,
        text_to_speak,
        output_file_path="response.mp3",
        voice_id=None,
        model_id="eleven_multilingual_v2",
    ):
        """
        Converte texto em fala usando ElevenLabs TTS.

        Args:
            text_to_speak: Texto para converter
            output_file_path: Arquivo de saída (padrão: response.mp3)
            voice_id: ID da voz (opcional, usa voz padrão)
            model_id: Modelo TTS (padrão: eleven_multilingual_v2)

        Returns:
            str: Caminho do arquivo gerado ou None em caso de erro
        """
        if not self.elevenlabs_client:
            print("❌ Cliente ElevenLabs não inicializado")
            return None

        voice_to_use = voice_id or self.default_voice_id

        if not voice_to_use:
            print("❌ Nenhum voice_id fornecido ou configurado")
            return None

        try:
            print(f"🔊 Gerando áudio com ElevenLabs...")
            audio = self.elevenlabs_client.text_to_speech.convert(
                text=text_to_speak,
                voice_id=voice_to_use,
                model_id=model_id,
                output_format="mp3_44100_128",
            )

            save(audio, output_file_path)
            print(f"✅ Áudio salvo em: {output_file_path}")
            return output_file_path
        except Exception as e:
            print(f"❌ Erro na geração de fala: {e}")
            return None

    def conversation_pipeline(
        self,
        audio_input_path,
        audio_output_path="response.mp3",
        system_prompt=None,
        model_name="llama-3.3-70b-versatile",
    ):
        """
        Pipeline completo: Áudio -> Transcrição -> LLM -> TTS

        Args:
            audio_input_path: Caminho do áudio de entrada
            audio_output_path: Caminho do áudio de saída
            system_prompt: Prompt do sistema para o LLM
            model_name: Modelo LLM a usar

        Returns:
            dict: Resultados de cada etapa ou None em caso de erro
        """
        print("\n🔄 Iniciando pipeline de conversação...")

        # 1. Transcrição
        transcription = self.transcribe_audio(audio_input_path)
        if not transcription:
            return None

        print(f"📝 Transcrição: {transcription}")

        # 2. LLM
        response = self.query_llm(
            transcription, model_name=model_name, system_prompt=system_prompt
        )
        print(f"🤖 Resposta: {response}")

        # 3. TTS
        audio_file = self.generate_speech(response, audio_output_path)

        if audio_file:
            print("✅ Pipeline concluído com sucesso!")
            return {
                "transcription": transcription,
                "llm_response": response,
                "audio_file": audio_file,
            }

        return None


# Funções standalone para compatibilidade
def transcribe_audio_groq(
    client, audio_file_path, model_name="whisper-large-v3", language="pt"
):
    """
    Função standalone para transcrição (compatibilidade com código legado).

    Args:
        client: Cliente Groq
        audio_file_path: Caminho do arquivo de áudio
        model_name: Modelo Whisper
        language: Idioma

    Returns:
        str: Texto transcrito
    """
    if not os.path.exists(audio_file_path):
        print(f"❌ Arquivo não encontrado: {audio_file_path}")
        return None

    try:
        print("🤖 Transcrevendo com Groq (Whisper)...")
        with open(audio_file_path, "rb") as audio_file:
            transcription = client.audio.transcriptions.create(
                file=audio_file,
                model=model_name,
                language=language,
                response_format="json",
            )
        return transcription.text
    except Exception as e:
        print(f"❌ Erro na transcrição: {e}")
        return None


# Exemplo de uso
if __name__ == "__main__":
    from dotenv import load_dotenv

    load_dotenv()

    print("=" * 60)
    print("🤖 AULO LLM - Teste de Funcionalidades")
    print("=" * 60)

    # Inicializa
    llm = AuloLLM()

    # Teste de query LLM
    print("\n📝 Testando consulta ao LLM...")
    resposta = llm.query_llm(
        "Explique em uma frase o que é Python",
        system_prompt="Você é um professor de programação.",
    )
    print(f"Resposta: {resposta}")

    print("\n✅ Biblioteca carregada com sucesso!")
