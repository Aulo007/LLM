"""
aulo_scripts - Biblioteca de utilitários Python base
Funções gerais que não dependem de APIs externas
Autor: Aulo
"""

import os
import sys


def clear_screen():
    """Limpa a tela do terminal de forma cross-platform."""
    if os.name == "nt":
        # Windows
        os.system("cls")
    else:
        # Linux, macOS
        os.system("clear")


def print_separator(char="=", length=60):
    """
    Imprime uma linha separadora.

    Args:
        char: Caractere usado para a linha (padrão: =)
        length: Comprimento da linha (padrão: 60)
    """
    print(char * length)


def print_header(title, char="=", length=60):
    """
    Imprime um cabeçalho formatado.

    Args:
        title: Título do cabeçalho
        char: Caractere da borda (padrão: =)
        length: Largura total (padrão: 60)
    """
    print_separator(char, length)
    print(title.center(length))
    print_separator(char, length)


def confirm_action(message="Deseja continuar?", default=True):
    """
    Solicita confirmação do usuário.

    Args:
        message: Mensagem de confirmação
        default: Valor padrão se o usuário apenas pressionar Enter

    Returns:
        bool: True se confirmado, False caso contrário
    """
    options = "[S/n]" if default else "[s/N]"
    response = input(f"{message} {options}: ").strip().lower()

    if not response:
        return default

    return response in ["s", "sim", "y", "yes"]


def safe_input(prompt, input_type=str, default=None, validator=None):
    """
    Input seguro com validação e tipo.

    Args:
        prompt: Mensagem para o usuário
        input_type: Tipo esperado (str, int, float)
        default: Valor padrão se entrada vazia
        validator: Função de validação personalizada

    Returns:
        Valor convertido para o tipo especificado
    """
    while True:
        try:
            user_input = input(prompt).strip()

            if not user_input and default is not None:
                return default

            value = input_type(user_input)

            if validator and not validator(value):
                print("❌ Valor inválido. Tente novamente.")
                continue

            return value

        except ValueError:
            print(f"❌ Por favor, insira um valor do tipo {input_type.__name__}")
        except KeyboardInterrupt:
            print("\n⚠️ Operação cancelada pelo usuário")
            sys.exit(0)


def format_file_size(size_bytes):
    """
    Formata tamanho de arquivo em formato legível.

    Args:
        size_bytes: Tamanho em bytes

    Returns:
        str: Tamanho formatado (ex: "1.5 MB")
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"


def list_files_in_directory(directory, extension=None):
    """
    Lista arquivos em um diretório.

    Args:
        directory: Caminho do diretório
        extension: Filtrar por extensão (ex: '.txt', '.wav')

    Returns:
        list: Lista de caminhos completos dos arquivos
    """
    if not os.path.exists(directory):
        print(f"❌ Diretório não encontrado: {directory}")
        return []

    files = []
    for item in os.listdir(directory):
        filepath = os.path.join(directory, item)
        if os.path.isfile(filepath):
            if extension is None or item.endswith(extension):
                files.append(filepath)

    return sorted(files)


def create_directory_if_not_exists(directory):
    """
    Cria um diretório se ele não existir.

    Args:
        directory: Caminho do diretório

    Returns:
        bool: True se criado ou já existe, False em caso de erro
    """
    try:
        os.makedirs(directory, exist_ok=True)
        return True
    except Exception as e:
        print(f"❌ Erro ao criar diretório: {e}")
        return False


def print_progress_bar(iteration, total, prefix="", suffix="", length=50, fill="█"):
    """
    Exibe uma barra de progresso no terminal.

    Args:
        iteration: Iteração atual
        total: Total de iterações
        prefix: Prefixo da barra
        suffix: Sufixo da barra
        length: Comprimento da barra
        fill: Caractere de preenchimento
    """
    percent = f"{100 * (iteration / float(total)):.1f}"
    filled_length = int(length * iteration // total)
    bar = fill * filled_length + "-" * (length - filled_length)
    print(f"\r{prefix} |{bar}| {percent}% {suffix}", end="\r")

    if iteration == total:
        print()


# Exemplo de uso
if __name__ == "__main__":
    # Teste das funções
    clear_screen()
    print_header("🛠️ AULO SCRIPTS - TESTES")

    print("\n1. Teste de confirmação:")
    if confirm_action("Continuar com os testes?"):
        print("✅ Confirmado!")

    print("\n2. Teste de input seguro:")
    idade = safe_input("Digite sua idade: ", int, default=18)
    print(f"Idade: {idade}")

    print("\n3. Teste de formatação de tamanho:")
    print(f"1024 bytes = {format_file_size(1024)}")
    print(f"1048576 bytes = {format_file_size(1048576)}")

    print("\n4. Teste de barra de progresso:")
    import time

    for i in range(101):
        print_progress_bar(i, 100, prefix="Progresso:", suffix="Completo")
        time.sleep(0.02)

    print("\n✅ Todos os testes concluídos!")
