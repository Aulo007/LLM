#!/usr/bin/env python3

import sys
import sounddevice as sd
import soundfile as sf
import numpy as np


class GerenciadorAudio:
    def __init__(self, taxa_amostragem=16000, canais=1):
        """
        Inicializa o gerenciador de áudio.
        Args:
            taxa_amostragem (int): Padrão 16000Hz (Ideal para Whisper).
            canais (int): Padrão 1 (Mono).
        """
        self.taxa_amostragem = taxa_amostragem
        self.canais = canais
        self.stream = None
        self.dados_gravacao = []
        self.gravando = False

    def listar_dispositivos(self):
        """
        Lista TODOS os dispositivos de áudio (Entrada, Saída e Híbridos).
        """
        print("\n🎧 TODOS OS DISPOSITIVOS DE ÁUDIO:")
        print("=" * 100)
        print(f"{'IDX':<4} | {'TIPO':<20} | {'IN':<4} | {'OUT':<4} | {'NOME'}")
        print("-" * 100)

        try:
            dispositivos = sd.query_devices()
            for i, dev in enumerate(dispositivos):
                canais_in = dev.get("max_input_channels", 0)
                canais_out = dev.get("max_output_channels", 0)
                nome = dev.get("name", "Desconhecido")

                # Define o tipo do dispositivo
                if canais_in > 0 and canais_out > 0:
                    tipo = "🔄 ENTRADA/SAÍDA"
                elif canais_in > 0:
                    tipo = "🎤 ENTRADA (Mic)"
                elif canais_out > 0:
                    tipo = "🔊 SAÍDA (Speaker)"
                else:
                    tipo = "❓ DESCONHECIDO"

                print(
                    f"{i:<4} | {tipo:<20} | {canais_in:<4} | {canais_out:<4} | {nome}"
                )

            print("=" * 100)
            print("💡 IN = Canais de entrada | OUT = Canais de saída")

        except Exception as e:
            print(f"❌ Erro ao listar dispositivos: {e}")

    def selecionar_dispositivo_menu(self):
        """
        Exibe o menu, pede input do usuário e valida a escolha.

        Returns:
            int: O ID (índice) do dispositivo selecionado ou None se padrão.
        """
        self.listar_dispositivos()

        print("\n📝 INSTRUÇÕES:")
        print("   • Digite o IDX do dispositivo que deseja usar para GRAVAÇÃO")
        print("   • O dispositivo PRECISA ter canais de entrada (IN > 0)")
        print("   • Dispositivos 🔄 ENTRADA/SAÍDA e 🎤 ENTRADA funcionam para gravar")
        print("   • Pressione ENTER para usar o microfone padrão do sistema")

        while True:
            escolha = input("\n👉 Sua escolha (IDX): ").strip()

            if not escolha:
                print("✅ Usando microfone padrão do sistema.")
                return None  # None faz o sounddevice usar o default

            if escolha.isdigit():
                idx = int(escolha)
                try:
                    devs = sd.query_devices()
                    if 0 <= idx < len(devs):
                        dev = devs[idx]
                        canais_in = dev["max_input_channels"]
                        canais_out = dev["max_output_channels"]
                        nome = dev["name"]

                        # Verifica se o dispositivo tem entrada
                        if canais_in > 0:
                            tipo_msg = ""
                            if canais_out > 0:
                                tipo_msg = " (Dispositivo Híbrido - Entrada/Saída)"
                            else:
                                tipo_msg = " (Dispositivo de Entrada)"

                            print(f"✅ Dispositivo '{nome}' selecionado{tipo_msg}")
                            print(f"   📊 {canais_in} canais de entrada disponíveis")
                            return idx
                        else:
                            print(
                                f"❌ '{nome}' é apenas de SAÍDA (sem canais de entrada)."
                            )
                            print("   ⚠️ Escolha um dispositivo com IN > 0 para gravar.")
                    else:
                        print("❌ ID inválido. Tente novamente.")
                except Exception as e:
                    print(f"❌ Erro ao validar ID: {e}")
            else:
                print("❌ Entrada inválida. Digite apenas números.")

    def _callback_audio(self, indata, frames, time, status):
        """Função interna chamada automaticamente pelo stream de áudio."""
        if status:
            print(f"⚠️ Status Áudio: {status}", file=sys.stderr)
        if self.gravando:
            self.dados_gravacao.append(indata.copy())

    def iniciar_gravacao(self, id_dispositivo=None):
        """
        Inicia a captura de áudio em background (não trava o código).

        Args:
            id_dispositivo (int): O ID retornado pelo menu. None = Padrão.
        """
        if self.gravando:
            print("⚠️ Já existe uma gravação em andamento.")
            return

        self.dados_gravacao = []  # Limpa gravação anterior
        self.gravando = True

        # Mostra info do dispositivo selecionado
        if id_dispositivo is not None:
            try:
                dev = sd.query_devices(id_dispositivo)
                print(f"\n🔴 Gravação INICIADA")
                print(f"   📱 Dispositivo: {dev['name']}")
                print(f"   📊 Canais: {self.canais} | Taxa: {self.taxa_amostragem}Hz")
            except:
                print(f"\n🔴 Gravação INICIADA (Dispositivo ID: {id_dispositivo})")
        else:
            print(f"\n🔴 Gravação INICIADA (Dispositivo Padrão do Sistema)")

        try:
            self.stream = sd.InputStream(
                samplerate=self.taxa_amostragem,
                device=id_dispositivo,
                channels=self.canais,
                callback=self._callback_audio,
            )
            self.stream.start()
        except Exception as e:
            print(f"❌ Erro ao iniciar stream: {e}")
            print(
                f"💡 Dica: Verifique se o dispositivo suporta {self.taxa_amostragem}Hz"
            )
            self.gravando = False

    def parar_gravacao(self, nome_arquivo="output.wav"):
        """
        Para a gravação, processa os dados e salva o arquivo.

        Args:
            nome_arquivo (str): Caminho onde salvar o .wav

        Returns:
            str: Caminho do arquivo salvo ou None se falhou.
        """
        if not self.gravando or not self.stream:
            print("⚠️ Nenhuma gravação ativa para parar.")
            return None

        print("⏹️ Parando gravação...")
        self.gravando = False
        self.stream.stop()
        self.stream.close()

        if not self.dados_gravacao:
            print("⚠️ Nenhum dado de áudio foi capturado.")
            return None

        print("💾 Processando e salvando arquivo...")
        try:
            # Concatena todos os pedaços de áudio em um único array numpy
            audio_final = np.concatenate(self.dados_gravacao, axis=0)

            # Informações sobre a gravação
            duracao = len(audio_final) / self.taxa_amostragem
            print(f"   ⏱️ Duração: {duracao:.2f} segundos")
            print(f"   📏 Samples: {len(audio_final)}")

            # Salva no disco
            sf.write(nome_arquivo, audio_final, self.taxa_amostragem)
            print(f"✅ Arquivo salvo com sucesso: {nome_arquivo}")
            return nome_arquivo
        except Exception as e:
            print(f"❌ Erro ao salvar arquivo: {e}")
            return None


if __name__ == "__main__":
    import time

    # 1. Instancia a classe
    gravador = GerenciadorAudio()

    # 2. Seleciona dispositivo (Menu interativo)
    meu_dispositivo = gravador.selecionar_dispositivo_menu()

    # 3. Inicia
    gravador.iniciar_gravacao(id_dispositivo=meu_dispositivo)

    # Simula o programa fazendo outras coisas enquanto grava
    print("\n⏳ Gravando por 5 segundos (simulação)...")
    time.sleep(5)

    # 4. Para
    gravador.parar_gravacao("teste_biblioteca.wav")
