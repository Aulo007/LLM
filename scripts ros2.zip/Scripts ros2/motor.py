#!/usr/bin/env python3
"""
Controlador WASD — ROS 2 (rclpy)
==================================
Thread 1 → W/S  → publica em /cmd_frente_tras
Thread 2 → A/D  → publica em /cmd_esquerda_direita

Dependências:
    pip install pynput
    (ROS 2 deve estar sourced: source /opt/ros/<distro>/setup.bash)
"""

import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from pynput import keyboard

# ─────────────────────────────────────────────────────────────────────────────
# Estado global das teclas (thread-safe)
# ─────────────────────────────────────────────────────────────────────────────

_lock = threading.Lock()
_keys_pressed: set = set()


def _on_press(key: keyboard.Key) -> None:
    try:
        char = key.char.lower()
        if char in ('w', 'a', 's', 'd'):
            with _lock:
                _keys_pressed.add(char)
    except AttributeError:
        pass


def _on_release(key: keyboard.Key) -> None:
    try:
        char = key.char.lower()
        if char in ('w', 'a', 's', 'd'):
            with _lock:
                _keys_pressed.discard(char)
    except AttributeError:
        pass


def _is_pressed(char: str) -> bool:
    with _lock:
        return char in _keys_pressed


# ─────────────────────────────────────────────────────────────────────────────
# Nó ROS 2
# ─────────────────────────────────────────────────────────────────────────────

class WasdController(Node):
    POLL_HZ = 100  # frequência de verificação das teclas

    def __init__(self):
        super().__init__('wasd_controller')

        self.pub_longitudinal = self.create_publisher(
            String, '/cmd_frente_tras', 1
        )
        self.pub_lateral = self.create_publisher(
            String, '/cmd_esquerda_direita', 1
        )

        self.get_logger().info('Controlador WASD iniciado. Use W/A/S/D.')

        # Inicia listener de teclado (thread própria do pynput)
        self._listener = keyboard.Listener(
            on_press=_on_press,
            on_release=_on_release,
            suppress=False,
        )
        self._listener.start()

        # Inicia as duas threads de controle
        self._t_ws = threading.Thread(
            target=self._loop_frente_tras,
            name='Thread-WS',
            daemon=True,
        )
        self._t_ad = threading.Thread(
            target=self._loop_esquerda_direita,
            name='Thread-AD',
            daemon=True,
        )
        self._t_ws.start()
        self._t_ad.start()

    # ── Thread W/S ──────────────────────────────────────────────────────────

    def _loop_frente_tras(self) -> None:
        rate = self.create_rate(self.POLL_HZ)
        ultimo = None
        msg = String()

        while rclpy.ok():
            w, s = _is_pressed('w'), _is_pressed('s')

            if   w and not s: cmd = 'frente'
            elif s and not w: cmd = 'tras'
            else:             cmd = 'parar'

            if cmd != ultimo:
                msg.data = cmd
                self.pub_longitudinal.publish(msg)
                self.get_logger().info(f'[W/S] -> {cmd}')
                ultimo = cmd

            rate.sleep()

    # ── Thread A/D ──────────────────────────────────────────────────────────

    def _loop_esquerda_direita(self) -> None:
        rate = self.create_rate(self.POLL_HZ)
        ultimo = None
        msg = String()

        while rclpy.ok():
            a, d = _is_pressed('a'), _is_pressed('d')

            if   a and not d: cmd = 'esquerda'
            elif d and not a: cmd = 'direita'
            else:             cmd = 'parar'

            if cmd != ultimo:
                msg.data = cmd
                self.pub_lateral.publish(msg)
                self.get_logger().info(f'[A/D] -> {cmd}')
                ultimo = cmd

            rate.sleep()

    def destroy_node(self):
        self._listener.stop()
        super().destroy_node()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main(args=None) -> None:
    rclpy.init(args=args)
    node = WasdController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()