import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from groq import Groq
import os
import sys
from dotenv import load_dotenv
import aulo_scripts
import aulo_llms


class MessageSubscriber(Node):
    def __init__(self):
        super().__init__("message_subscriber_node")

        # 1. Instanciamos a classe AuloLLM aqui para carregar as chaves e clientes
        self.llm_handler = aulo_llms.AuloLLM()

        self.subscriber = self.create_subscription(
            String, "voice_commands", self.receive_msg, 10
        )
        self.get_logger().info("Nó de subscrição pronto e LLM carregado.")

    def receive_msg(self, message: String):
        mensagem_do_publisher = message.data

        # 2. Usamos a instância criada (self.llm_handler) para chamar o método.
        # Não precisamos passar 'self' manualmente, o Python faz isso.
        resposta_do_modelo = self.llm_handler.query_llm(
            content=mensagem_do_publisher,
            model_name="llama-3.3-70b-versatile",
            system_prompt=None,
        )

        print(f'Mensagem recebida: "{mensagem_do_publisher}"')
        print(f'Resposta a mensagem recebida "{resposta_do_modelo}"')


def main(args=None):
    load_dotenv()
    rclpy.init(args=args)
    node = MessageSubscriber()
    print("Aguardando mensagens... (pressione Ctrl+C para sair)")

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\n Encerrando nó de subscrição")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
