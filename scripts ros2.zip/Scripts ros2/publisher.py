#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import audio_aulo
import aulo_llms


class MessagePublisher(Node):
    def __init__(self):
        super().__init__("message_publisher_node")
        self.publisher_ = self.create_publisher(String, "voice_commands", 10)
        self.get_logger().info("📢 Nó Publicador de Voz Iniciado!")

    def publish_message(self, text):
        msg = String()
        msg.data = text
        self.publisher_.publish(msg)
        self.get_logger().info(f"📤 Publicado: '{text}'")


def main(args=None):
    # 1. Inicializa o ROS
    rclpy.init(args=args)

    # 2. Inicializa a biblioteca aulo_llm
    # A biblioteca carrega automaticamente as chaves do .env
    llm = aulo_llms.AuloLLM()

    # 3. Inicializa Classes
    node = MessagePublisher()
    gravador = audio_aulo.GerenciadorAudio()

    # 4. Seleciona microfone (Uma única vez no início)
    device_id = gravador.selecionar_dispositivo_menu()

    print("\n" + "=" * 50)
    print("🎙️ SISTEMA DE VOZ ROS 2 PRONTO")
    print("=" * 50)

    try:
        while rclpy.ok():
            # Lógica simplificada: Enter para começar, Enter para parar
            input("\n🟢 Pressione [ENTER] para COMEÇAR a gravar...")
            gravador.iniciar_gravacao(id_dispositivo=device_id)

            input("🔴 Pressione [ENTER] para PARAR a gravação...")
            arquivo_salvo = gravador.parar_gravacao("comando_voz.wav")

            if arquivo_salvo:
                # Transcreve usando a biblioteca aulo_llm
                texto_transcrito = llm.transcribe_audio(arquivo_salvo)

                if texto_transcrito:
                    print(f"📝 Texto reconhecido: {texto_transcrito}")
                    # Publica no ROS
                    node.publish_message(texto_transcrito)
                else:
                    print("⚠️ Não foi possível transcrever o áudio.")

    except KeyboardInterrupt:
        print("\n👋 Encerrando aplicação...")

    finally:
        # Limpeza correta dos recursos
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
